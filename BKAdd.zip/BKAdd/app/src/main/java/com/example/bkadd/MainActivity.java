package com.example.bkadd;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    String TAG = "MainActivity";
    EditText num1;
    EditText num2;
    Button act;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num1 = findViewById(R.id.editTextNumberDecimal);
        num2 = findViewById(R.id.editTextNumberDecimal2);
        act = findViewById(R.id.button);
        result = findViewById(R.id.textView2);
        act.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int n = Integer.parseInt(num1.getText().toString());
                int n2 = Integer.parseInt(num2.getText().toString());
                int res = n+n2;
                result.setText("Result is : "+res);
                Log.i(TAG,"First Number is : "+n);
                Log.i(TAG,"Second Number is : "+n2);
                Log.i(TAG,"Result is : "+res);
                Toast.makeText(getApplicationContext(),"onCreate : invoked",Toast.LENGTH_LONG).show();
                Toast.makeText(getApplicationContext(),"onDestroy : invoked",Toast.LENGTH_LONG).show();
                Toast.makeText(getApplicationContext(),"onStart : invoked",Toast.LENGTH_LONG).show();
                Toast.makeText(getApplicationContext(),"onResume : invoked",Toast.LENGTH_LONG).show();
                Toast.makeText(getApplicationContext(),"onEnd : invoked",Toast.LENGTH_LONG).show();
                Toast.makeText(getApplicationContext(),"onStop : invoked",Toast.LENGTH_LONG).show();
                Toast.makeText(getApplicationContext(),"onRestart : invoked",Toast.LENGTH_LONG).show();
            }
        });
    }
}