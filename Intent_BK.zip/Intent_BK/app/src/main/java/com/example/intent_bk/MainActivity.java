package com.example.intent_bk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    String TAG = "MainActivity";
    EditText num1;
    EditText num2;
    Button act;
    TextView result;
    Intent intent;
    Bundle extras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        intent = new Intent(this,MainActivity2.class);
        extras = new Bundle();
        String colorString = "red";


        num1 = findViewById(R.id.editTextNumberDecimal);
        num2 = findViewById(R.id.editTextNumberDecimal2);
        act = findViewById(R.id.button);
        result = findViewById(R.id.textView2);
        act.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int n = Integer.parseInt(num1.getText().toString());
                int n2 = Integer.parseInt(num2.getText().toString());
                int res = n+n2;
                result.setText("Result is : "+res);
                extras.putString("num1",n+"");
                extras.putString("num2",n2+"");
                extras.putString("num3",res+"");
                extras.putString("color",colorString);
                intent.putExtras(extras);
                startActivity(intent);
            }
        });
    }
}